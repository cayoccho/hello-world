package edu.ctu.thesis.travelsystem.extra;

public class MailTemplate {
	
	public static  String hostMail = "nytravelsystem@gmail.com";
	
	public static String regTitle = "Đăng ký tài khoản thành công";
	
	public static String bookSuccessTitle = "Đặt vé thành công";
	
	public static String canBookSuccessTitle = "Hủy đặt vé thành công";
	
	public static String confirmCancelTitle = "Xác nhận hủy đặt vé";
	
	public static String regBody = "Kính chào quý khách!"
			+ "Cám ơn quý khác đã đăng ký sử dụng dịch vụ của chúng tôi!"
			+ "NYTravel luôn sẵn lòng phục vụ quý khách 24/7. "
			+ "Liên hệ hostline: 099232121 hoặc email: nytravelsystem@gmail.com";
	
	public static String bookSuccessBody = "Cám ơn quý khách đã đăng ký tham gia tour!"
			+ "Liên hệ hostline: 099232121 hoặc email: nytravelsystem@gmail.com";
	
	public static String confirmCancelBody = "Cám ơn quý khác đã đăng ký sử dụng dịch vụ của chúng tôi! "
			+ "Mã xác nhận hủy đặt vé là: ";
}
