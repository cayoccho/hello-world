package edu.ctu.thesis.travelsystem.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import edu.ctu.thesis.travelsystem.dto.BookTourInfoVO;
import edu.ctu.thesis.travelsystem.dto.SubBookTourVO;
import edu.ctu.thesis.travelsystem.extra.ValidUtil;
import edu.ctu.thesis.travelsystem.model.SubBookTour;

@Component
public class BookTourNextValidator implements Validator {

	@Override
	public boolean supports(Class<?> arg0) {
		return SubBookTour.class.equals(arg0);
	}

	@Override
	public void validate(Object target, Errors errors) {
		BookTourInfoVO bookTourNext = (BookTourInfoVO) target;
		ValidUtil validUtil = new ValidUtil();

		// Catch length character errors
		// In Customer name field
		if (bookTourNext.getCusName() != null
				&& (bookTourNext.getCusName().length() > 40 || bookTourNext.getCusName().length() < 8)) {
			errors.rejectValue("cusName", "Size.cusNextData.cusName");
		}
		// In Customer year of birth 1 field
		if ((bookTourNext.getCusYearOfBirth() != null) && (bookTourNext.getCusYearOfBirth().length() != 4)) {
			errors.rejectValue("cusYearOfBirth", "Size.cusNextData.cusYearOfBirth1");
		}

		// Catch characters errors
		// In Customer year of birth field
		if (bookTourNext.getCusYearOfBirth() != null && (validUtil.findAlphabet(bookTourNext.getCusYearOfBirth()))) {
			errors.rejectValue("cusYearOfBirth1", "Invalid.cusNextData.cusYearOfBirth1");
		}

		// Catch digit errors
		// In Customer name field
		if (bookTourNext.getCusName() != null && (validUtil.findDigit(bookTourNext.getCusName()))) {
			errors.rejectValue("cusName", "Invalid.cusNextData.cusName");
		}
	}
}
