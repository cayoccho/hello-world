//DUPLICATE PLUGIN
$.fn.duplicate = function(count, cloneEvents) {
	var tmp = [];
	for (var i = 0; i < count; i++) {
		$.merge(tmp, this.clone(cloneEvents).get());
	}
	return this.pushStack(tmp);
};
$('.number-option').hide();
// SELECT CHANGE FUNCTION (on change get value and clone)
$('#main-select').change(
		function() { // on change...
			var numOfClones = $(this).val(); // get value...
			$('.number-option').show();
			$('#holder').html(''); // empty holder if there are some old clones
			$("input[name='cusName']").val("cusName${numOfClones}");
			var $target =  $('#repeat').duplicate(numOfClones).addClass('new').appendTo(
					'#holder')
			// duplicate; fill holder with new clones; the class 'new' is just
			// for styling
					$target.find('input').each(function(){           
				           $(this).val('');
				           var tID = $(this).attr("id").split(/_/);
				           var re = new RegExp(tID[3],"g");
				           var newID = $(this).attr('id').replace(re, time);
				           var newName = $(this).attr('name').replace(re, time);
				           $(this).attr('id', newID);
				           $(this).attr('name', newName);
				        });
		});