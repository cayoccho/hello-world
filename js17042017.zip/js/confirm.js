//document.addEventListener("DOMContentLoaded", function() {
//	var demobtn2 = document.querySelector("#demo3");
//	$("button").click(
//			function() {
//				mscConfirm("Xóa", "Are you sure you want to delete this post?",
//						function() {
//							var url = $(this).data('target');
//							location.replace(url);
//						}, function() {
//							mscAlert('Cancelled');
//						});
//			});
//});

$(function() {
	$(".delete")
			.click(
					function() {
						swal(
								{
									title : "Are you sure?",
									text : "You will not be able to recover this imaginary file!",
									type : "warning",
									showCancelButton : true,
									confirmButtonColor : "#DD6B55",
									confirmButtonText : "Yes, delete it!",
									closeOnConfirm : false
								},
								function(isConfirmed) {
									if (isConfirmed) {
										$(".file").addClass("isDeleted");
										swal(
												"Deleted!",
												"Your imaginary file has been deleted.",
												"success");
									}
								});
					});
});
