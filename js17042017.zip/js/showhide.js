//DUPLICATE PLUGIN
$.fn.duplicate = function(count, cloneEvents) {
	var tmp = [];
	for (var i = 0; i < count; i++) {
		$.merge(tmp, this.clone(cloneEvents).get());
	}
	return this.pushStack(tmp);
};
$('.number-option').hide();
// SELECT CHANGE FUNCTION (on change get value and clone)
$('#main-select').change(
		function() { // on change...
			var numOfClones = $(this).val(); // get value...
			var input_name = null;
			var info = 'info';
			$('.number-option').show();
			
			$('#holder').html(''); // empty holder if there are some old clones
			for (i = 0; i < numOfClones; i++) {
				var duplicate = $('#repeat').clone().addClass('new').appendTo(
						'#holder');
				duplicate.find('input').each(function() {
				    this.id = this.id.replace('1', i + 2);
				});
				duplicate.find('input').each(function() {
					var new_name = info + '[' + (i + 2) + ']' + '.';
				    this.name = new_name.concat(this.name);
				});
//				duplicate.find('input').replace('[0]', '['+i+']');
//				
//				duplicate.find('select').replace('0', i);
				
			}
			// duplicate; fill holder with new clones; the class 'new' is just
			// for styling

		});