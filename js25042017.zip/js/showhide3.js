/* Show/ hide input when choose in select option */
previousVal = 0;
var showDiv = function(number) {
	if (number > 0) {
		$('#a').show();
	} else {
		$('#a').hide();
	}
	var numOfCustomer = number - previousVal;
	if (numOfCustomer > 0) {
		for (i = 0; i < numOfCustomer; i++) {
			if (number == 1) {
				$('#info').append($('#a'));
			} else {
				$('#info').prepend($('#a').clone());
			}
		}
	} else {
		for (i = 0; i < numOfCustomer; i++) {
			if (number == 1) {
				$('#info').append($('#a'));
			} else {
				$('#info').append($('#a').clone());
			}
		}
	}

	$('.number-option').hide();
	$('.number-option:lt(' + number + ')').show();
};

$('#main-select').change(function() {
	showDiv(parseInt(this.value, 10));
}).change();

$("#main-select").on('focus', function() {
	// Store the current value on focus and on change
	previousVal = this.value;
}).change(function() {
	// Do something with the previous value after the change

	// Make sure the previous value is updated
	previousVal = this.value;
});
/* End Show/ hide input when choose in select option */