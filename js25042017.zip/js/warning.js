/* Confirm popup for delete all */
$(function() {
	$(".success").click(function(e) {
		e.preventDefault();
		var cid = this.id;
		swal({
			title : "Cập nhật thành công!",
			type : "success",
			timer : 1500,
			showConfirmButton : false
		});
	});
});
/* End Confirm popup for delete all */

