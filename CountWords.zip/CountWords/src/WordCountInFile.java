import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.regex.Pattern;

public class WordCountInFile {
	private static BlockingQueue<String> sharedQueue = new LinkedBlockingQueue<>(1000);
	private static Thread[] consumers;
	private static Map<String, Integer> wordCounts = new ConcurrentHashMap<String, Integer>();
	private static boolean readingFinished = false;
	private static Pattern specialCharsRemovePattern = Pattern.compile("^[a-zA-Z0-9\\-]+$");
	static int totalWords = 0;
	static LinkedHashSet<String> countWords = new LinkedHashSet<String>();

	public static void main(String args[]) throws InterruptedException {
		String inputFile = "src/sdc.log";
		int nbThreads = WordCountInFile.lineCount(inputFile);

		System.out.printf("Execution starting with %d consumer thread(s) ...\n", nbThreads);

		// Create array to store the consumer threads
		consumers = new Thread[nbThreads];

		// Create and start Producer thread
		Thread producer = new Thread(new Producer(inputFile));
		producer.start();

		// Create and start Consumer Threads
		for (int i = 0; i < nbThreads; i++) {
			consumers[i] = new Thread(new Consumer());
			consumers[i].start();
		}

		// Wait for all threads to finish
		producer.join();
		for (int i = 0; i < nbThreads; i++) {
			consumers[i].join();
		}
		System.out.println("Number of each words in file: " + wordCounts);
		System.out.println("Total words: " + totalWords);
	}

	// Producer. Reads the input file and stores each line in the queue.
	public static class Producer implements Runnable {
		private String inputFile;

		public Producer(String inputFile) {
			this.inputFile = inputFile;
		}

		@Override
		public void run() {
			int count = 0;

			try (BufferedReader br = new BufferedReader(new FileReader(inputFile));) {
				String line;
				while ((line = br.readLine()) != null) {
					sharedQueue.put(line);
					count++;
					if (count % 100000 == 0) {
						System.out.printf(count + " lines read from input. Current Queue size: %d\n", count / 100000,
								sharedQueue.size());
					}
					countWords.add(line);
				}
				System.out.println(countWords);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			readingFinished = true;
		}
	}

	// Consumer. Fetches a line in the queue and splits it to count words
	public static class Consumer implements Runnable {
		@Override
		public void run() {
			while (!readingFinished || !sharedQueue.isEmpty()) {
				// Get a line from the queue
				String line = sharedQueue.poll();
				if (line == null)
					continue;

				// Count words in file
				String[] words = specialCharsRemovePattern.matcher(line).replaceAll(" ").toLowerCase().split("\\s+");

				for (String word : words) {
					int count = wordCounts.containsKey(word) ? wordCounts.get(word) + 1 : 1;
					wordCounts.put(word, count);
					totalWords++;
				}
			}
		}
	}

	// Count number of line in file
	public static int lineCount(String inputFile) {
		int count = 0;

		try (BufferedReader br = new BufferedReader(new FileReader(inputFile));) {
			while (br.readLine() != null) {
				count++;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return count;
	}
}