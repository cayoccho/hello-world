public interface Item {
	public void process();
}
