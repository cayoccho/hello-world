import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

public class Test {
	public static void main(String[] args) throws Exception {
		Consumer consumer = new ConsumerImpl(10);

		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("src/sdc.log")));
		Map<String, Integer> wordCounts = new ConcurrentHashMap<String, Integer>();
		Pattern specialCharsRemovePattern = Pattern.compile("^[a-zA-Z0-9\\-]+$");
		int totalWords = 0;
		LinkedHashSet<String> countWords = new LinkedHashSet<String>();

		String line;

		while ((line = br.readLine()) != null) {
//			countWords.add(line);
			
			String[] words = specialCharsRemovePattern.matcher(line).replaceAll(" ").toLowerCase().split("\\s+");

			for (String word : words) {
				int count = wordCounts.containsKey(word) ? wordCounts.get(word) + 1 : 1;
				wordCounts.put(word, count);
				totalWords++;
			}
			System.out.println("Producer producing: " + line);
			
			consumer.consume(new PrintJob(line));
		}
//		System.out.println(countWords);
		System.out.println("Number of each words in file: " + wordCounts);
		System.out.println("\nTotal: " + totalWords + "\n");
		consumer.finishConsumption();
	}
}

class PrintJob implements Item {
	private String line;

	public PrintJob(String s) {
		line = s;
	}

	public void process() {
		System.out.println(Thread.currentThread().getName() + " consuming :" + line);
	}
}