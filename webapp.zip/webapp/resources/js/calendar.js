/* Calendar */
$(document).ready(function() {
	$("#datepicker").datepicker();
});
$(document).ready(function() {
	$("#datepicker2").datepicker();
});
/* End Calendar */

/* Popup */
$(".modal-wide").on("show.bs.modal", function() {
	var height = $(window).height() - 900;
	$(this).find(".modal-body").css("max-height", height);
});
/* End Popup */

/* Text Editor */
		bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
/* End Text Editor */
