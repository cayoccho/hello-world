import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

public class Test {
	private static BufferedReader br;

	public static void main(String[] args) throws Exception {
		Consumer consumer = new ConsumerImpl(10);

		br = new BufferedReader(new InputStreamReader(new FileInputStream("src/sdc.log")));
		Map<String, Integer> wordCounts = new ConcurrentHashMap<String, Integer>();
		Pattern specialCharsRemovePattern = Pattern.compile("^[a-zA-Z0-9\\-]+$");
		int totalWords = 0;
		LinkedHashSet<String> countWords = new LinkedHashSet<String>();

		String line;

		while ((line = br.readLine()) != null) {
			String[] words = specialCharsRemovePattern.matcher(line).replaceAll(" ").toLowerCase().split("\\s+");
			for (String word : words) {
				int count = wordCounts.containsKey(word) ? wordCounts.get(word) + 1 : 1;
				wordCounts.put(word, count);
				totalWords++;
			}
			countWords.add(line);
		}
		System.out.println("Number of each words in file: " + wordCounts + "\nCollection: " + countWords);
		// System.out.println("\n");
		// System.out.println("\n");
		// System.out.println("Collection: " + countWords);
		System.out.println("\nTotal: " + totalWords + "\n");

		consumer.finishConsumption();
	}
}

class PrintJob implements Item {
	private String line;

	public PrintJob(String s) {
		line = s;
	}

	public void process() {
		System.out.println(Thread.currentThread().getName() + " consuming :" + line);
	}
}