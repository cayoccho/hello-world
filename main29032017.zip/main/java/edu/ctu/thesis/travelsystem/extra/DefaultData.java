package edu.ctu.thesis.travelsystem.extra;

public class DefaultData {
	public static void main(String[] args) {
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
	}
}
