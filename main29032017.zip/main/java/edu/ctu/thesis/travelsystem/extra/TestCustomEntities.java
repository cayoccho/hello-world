package edu.ctu.thesis.travelsystem.extra;

import edu.ctu.thesis.travelsystem.extra.HibernateUtil;
import edu.ctu.thesis.travelsystem.dao.CustomizableEntityManager;
import edu.ctu.thesis.travelsystem.dao.CustomizableEntityManagerImpl;
import edu.ctu.thesis.travelsystem.controller.ManageTourController;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.io.Serializable;

public class TestCustomEntities {
    private static final String TEST_FIELD_NAME = "email";
    private static final String TEST_VALUE = "test@test.com";

    public static void main(String[] args) {
        HibernateUtil.getInstance().getCurrentSession();

        CustomizableEntityManager contactEntityManager = new
     CustomizableEntityManagerImpl(ManageTourController.class);

        contactEntityManager.addCustomField(TEST_FIELD_NAME);

        Session session = HibernateUtil.getInstance().getCurrentSession();

        Transaction tx = session.beginTransaction();
        try {

        	ManageTourController contact = new ManageTourController();
            contact.setName("Contact Name 1");
            contact.setValueOfCustomField(TEST_FIELD_NAME, TEST_VALUE);
            Serializable id = session.save(contact);             tx.commit();

            contact = (ManageTourController) session.get(ManageTourController.class, id);
            Object value = contact.getValueOfCustomField(TEST_FIELD_NAME);
            System.out.println("value = " + value);

        } catch (Exception e) {
           tx.rollback();
           System.out.println("e = " + e);
        }
    }
}