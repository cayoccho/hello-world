/* History Back */
function goBack() {
	window.history.back();
}
/* End History Back */

