document.addEventListener("DOMContentLoaded", function() {
	var demobtn2 = document.querySelector("#demo3");
	$("button").click(
			function() {
				mscConfirm("Xóa", "Are you sure you want to delete this post?",
						function() {
							var url = $(this).data('target');
							location.replace(url);
						}, function() {
							mscAlert('Cancelled');
						});
			});
});
