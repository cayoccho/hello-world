import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.LinkedHashSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

public class Test {
	private static BufferedReader br;

	public static void main(String[] args) throws Exception {
		Consumer consumer = new ConsumerImpl(10);
		File file = new File("src/output.txt");
		FileOutputStream fos = new FileOutputStream(file);
		PrintStream ps = new PrintStream(fos);
		br = new BufferedReader(new InputStreamReader(new FileInputStream("src/sdc.log")));
		ConcurrentHashMap<String, Integer> wordCounts = new ConcurrentHashMap<String, Integer>();
		Pattern specialCharsRemovePattern = Pattern.compile("^[a-zA-Z0-9\\-]+$");
		int totalWords = 0;
		LinkedHashSet<String> countWords = new LinkedHashSet<String>();
		String line;

		while ((line = br.readLine()) != null) {
			String[] words = specialCharsRemovePattern.matcher(line).replaceAll(" ").toLowerCase().split("\\s+");
			for (String word : words) {
				int count = wordCounts.containsKey(word) ? wordCounts.get(word) + 1 : 1;
				wordCounts.put(word, count);
				totalWords++;
			}
			countWords.add(line);
		}
		System.setOut(ps);
		System.out.println("\nData: \n" + countWords);
		System.out.println("\nNumber of each words in file: \n" + wordCounts);
		System.out.println("\nTotal words: \n" + totalWords);
		consumer.finishConsumption();
	}
}
