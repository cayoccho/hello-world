public interface Consumer {
	public boolean consume(Item j);

	public void finishConsumption();
}
