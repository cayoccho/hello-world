package edu.ctu.thesis.travelsystem.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import edu.ctu.thesis.travelsystem.model.BookTour;
import edu.ctu.thesis.travelsystem.model.Role;
import edu.ctu.thesis.travelsystem.model.User;
import edu.ctu.thesis.travelsystem.service.BookTourService;
import edu.ctu.thesis.travelsystem.service.TourService;
import edu.ctu.thesis.travelsystem.service.UserService;
import edu.ctu.thesis.travelsystem.validator.UserValidator;

@Controller
public class UserController {
	@Autowired
	private UserService userService;
	@Autowired
	private BookTourService bookTourService;
	@Autowired
	private TourService tourService;

	private static final Logger logger = Logger.getLogger(UserController.class);

	// Processing for register when required request
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String showForm(ModelMap model) {
		logger.info("Handle register request when client send!");
		model.put("userData", new User());// put userData as a User
		return "register";
	}

	// Processing for form register when submit
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String saveForm(ModelMap model, @ModelAttribute("userData") @Valid User user, BindingResult br,
			HttpSession session) {
		logger.info("Handle register form action when user submit!");
		UserValidator userValidator = new UserValidator();
		userValidator.validate(user, br);
		if (br.hasErrors()) { // form input have error
			return "register";
		} else { // form input is ok
			userService.saveUser(user);
			session.setAttribute("user", user);
			session.setAttribute("userName", user.getFullName());
			session.setAttribute("idUser", user.getIdUser());
			return "redirect:login";
		}
	}

	// Processing for login when required request
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String showLogin(ModelMap model, HttpSession session) {
		logger.info("Handle login request when client send!");
		if (session.getAttribute("user") == null) {
			model.put("userData", new User()); // put userData as a user
			return "login";
		} else {
			return "redirect:home";
		}
	}

	// Handle for form login when submit
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String doLogin(ModelMap model, @ModelAttribute("userData") User user, HttpSession session) {
		if (user.getUserName() != null && user.getPassword() != null && session.getAttribute("user") == null) {
			user = userService.loginUser(user);
			logger.info("Handle login form action when user submit!");
			if (user != null) {
				if (userService.getRoleUser(user) == 2) {
					session.setAttribute("user", user);
					session.setAttribute("userName", user.getFullName());
					session.setAttribute("roleId", user.getRole().getId());
					session.setAttribute("idUser", user.getIdUser());
					return "redirect:managetour";
				} else {
					session.setAttribute("user", user);
					session.setAttribute("userName", user.getFullName());
					session.setAttribute("idUser", user.getIdUser());
					return "redirect:login";
				}
			} else {
				logger.info("The username or password is incorrect");
				model.put("failed", "Tài khoản hoặc mật khẩu không đúng");
				return "login";
			}
		} else {
			return "redirect:home";
		}
	}

	// Handel for logout request
	@SuppressWarnings("deprecation")
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logOut(ModelMap model, HttpSession session) {
		session.removeAttribute("user"); // remove user object from session
		session.removeValue("userName"); // remove userName value
		session.removeValue("roleId"); // remove roleId value
		return "redirect:login";
	}

	// Forward to manage my account page
	@RequestMapping(value = "managemyacc/{idUser}", method = RequestMethod.GET)
	public String showMyAccDetail(ModelMap model, @PathVariable("idUser") int idUser) {
		logger.info("Show user detail!");
		model.put("userData", userService.searchUserById(idUser));
		return "managemyacc";
	}

	// Handle required request from client
	@RequestMapping(value = "editmyacc/{idUser}", method = RequestMethod.GET)
	public String showEditForm(ModelMap model, @PathVariable("idUser") int idUser) throws ParseException {
		logger.info("Handle edit form when administrator request!");
		logger.info("Display edit user form when administrator request!");
		User user = userService.searchUserById(idUser);
		if (user != null) {
			model.addAttribute("userData", userService.searchUserById(idUser));
			DateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			String birthday = sdf.format(user.getBirthday());
			model.addAttribute("dateofbirth", birthday);
		} else {
			logger.info("Null Object!");
		}
		return "editmyacc";
	}

	// Handle form action edit my account
	@RequestMapping(value = "editmyacc/{idUser}", method = RequestMethod.POST)
	public String editUser(ModelMap model, @PathVariable("idUser") int idUser,
			@ModelAttribute("userData") @Valid User user, BindingResult br, HttpSession session) {
		UserValidator userValidator = new UserValidator();
		userValidator.validate(user, br);
		if (br.hasErrors()) {
			return "editmyacc";
		} else {
			logger.info("Update user if haven't error!");
			Role role = new Role();
			role.setId(1);
			user.setRole(role);
			userService.editUser(user);
			return "redirect:/managemyacc/{idUser}";
		}
	}

	// Forward to Registration List page
	@RequestMapping(value = "managemyreg/{idUser}", method = RequestMethod.GET)
	public String myRegList(ModelMap model, HttpSession session, @PathVariable("idUser") int idUser,
			@RequestParam(required = false, value = "valueSearch") String valueSearch,
			@RequestParam(required = true, defaultValue = "1", value = "page") Integer page,
			@RequestParam(required = false, value = "valueSearch2") String valueSearch2,
			@RequestParam(required = true, defaultValue = "1", value = "page2") Integer page2) {
		logger.info("Handle when manage register request from admin!");
		String result;
		try {
			// Display registration list
			model.addAttribute("searchedValue", valueSearch);
			if (valueSearch != null) {
				Integer num = 0;
				if ((userService.getMyNumBTBySearch(valueSearch, idUser) % 5) == 0) {
					num = userService.getMyNumBTBySearch(valueSearch, idUser) / 5;
				} else {
					num = (userService.getMyNumBTBySearch(valueSearch, idUser) / 5) + 1;
				}
				if (page <= num) {
					List<Integer> pageNum = IntStream.rangeClosed(1, num).boxed().collect(Collectors.toList());
					logger.info("Search active!");
					model.addAttribute("bookTour", new BookTour());
					model.addAttribute("myRegList", userService.myRegListByValue(valueSearch, idUser));
					model.addAttribute("myNumBT", userService.getMyNumBTBySearch(valueSearch, idUser));
					model.addAttribute("pageNum", pageNum); // create number
					model.addAttribute("pageE", new ArrayList<Integer>()); // create
					model.addAttribute("x", tourService.paginationX(page, 5));
					model.addAttribute("y",
							tourService.paginationY(userService.myRegListByValue(valueSearch, idUser).size(), page, 5));
					result = "managemyreg";
				} else {
					result = "managemyreg";
				}
			} else { // search none active ! Update list tour
				Integer num = 0;
				if ((userService.getMyNumBT(idUser) % 5) == 0) {
					num = userService.getMyNumBT(idUser) / 5;
				} else {
					num = (userService.getMyNumBT(idUser) / 5) + 1;
				}

				if (page <= num) {
					List<Integer> pageNum = IntStream.rangeClosed(1, num).boxed().collect(Collectors.toList());
					model.addAttribute("bookTour", new BookTour());
					model.addAttribute("myRegList", userService.myRegList(idUser));
					model.addAttribute("myNumBT", userService.getMyNumBT(idUser));
					model.addAttribute("pageNum", pageNum);
					model.addAttribute("pageE", new ArrayList<Integer>());
					model.addAttribute("x", tourService.paginationX(page, 5));
					model.addAttribute("y", tourService.paginationY(userService.myRegList(idUser).size(), page, 5));
					result = "managemyreg";
				} else {
					result = "managemyreg";
				}
			}
			// Display cancel registration list
			model.addAttribute("searchedValue2", valueSearch2);
			if (valueSearch2 != null) {
				Integer num2 = 0;
				if ((userService.getMyNumCancelBySearch(valueSearch2, idUser) % 5) == 0) {
					num2 = userService.getMyNumCancelBySearch(valueSearch2, idUser) / 5;
				} else {
					num2 = (userService.getMyNumCancelBySearch(valueSearch2, idUser) / 5) + 1;
				}
				if (page2 <= num2) {
					List<Integer> pageNum2 = IntStream.rangeClosed(1, num2).boxed().collect(Collectors.toList());
					logger.info("Search active!");
					model.addAttribute("myCancelReg", new BookTour());
					model.addAttribute("myCancelList", userService.myCancelListByValue(valueSearch2, idUser));
					model.addAttribute("myNumCancelReg", userService.getMyNumCancelBySearch(valueSearch2, idUser));
					model.addAttribute("pageNum2", pageNum2);
					model.addAttribute("pageE2", new ArrayList<Integer>());
					model.addAttribute("x2", tourService.paginationX(page2, 5));
					model.addAttribute("y2", tourService
							.paginationY(userService.myCancelListByValue(valueSearch2, idUser).size(), page2, 5));
					result = "managemyreg";
				} else {
					result = "managemyreg";
				}
			} else { // search none active ! Update list tour
				Integer num2 = 0;
				if ((userService.getMyNumCancelReg(idUser) % 5) == 0) {
					num2 = userService.getMyNumCancelReg(idUser) / 5;
				} else {
					num2 = (userService.getMyNumCancelReg(idUser) / 5) + 1;
				}
				if (page2 <= num2) {
					List<Integer> pageNum2 = IntStream.rangeClosed(1, num2).boxed().collect(Collectors.toList());
					model.addAttribute("myCancelReg", new BookTour());
					model.addAttribute("myCancelList", userService.myCancelList(idUser));
					model.addAttribute("myNumCancelReg", userService.getMyNumCancelReg(idUser));
					model.addAttribute("pageNum2", pageNum2);
					model.addAttribute("pageE2", new ArrayList<Integer>());
					model.addAttribute("x2", tourService.paginationX(page2, 5));
					model.addAttribute("y2",
							tourService.paginationY(userService.myCancelList(idUser).size(), page2, 5));
					result = "managemyreg";
				} else {
					result = "managemyreg";
				}
			}
		} catch (Exception e) {
			logger.error("Occured ex", e);
			result = "forbidden";
		}
		return result;
	}

	// Customer cancel registration tour
	@RequestMapping(value = "cancel/{idBT}")
	public String cancelBookTour(@PathVariable("idBT") Integer idBT, HttpSession session, ModelMap model) {
		bookTourService.cancelBookTour(idBT);
		model.addAttribute("idUser", (int) session.getAttribute("idUser"));
		return "redirect:/managemyreg/{idUser}";
	}

	// User undo cancel registration
	@RequestMapping(value = "undo/{idBT}/{idTour}")
	public String undoCancel(@PathVariable("idBT") Integer idBT, @PathVariable("idBT") int idTour, HttpSession session,
			ModelMap model) {
		userService.undoCancel(idBT, idTour);
		model.addAttribute("idUser", (int) session.getAttribute("idUser"));
		return "redirect:/managemyreg/{idUser}";
	}
}