package edu.ctu.thesis.travelsystem.model;

import static javax.persistence.GenerationType.IDENTITY;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "CANCEL_REGISTRATION")
public class CancelRegistration {
	private int idCancel;
	private String cName;
	private String cSex;
	private String cEmail;
	private String cPhone;
	private String cAddress;
	private int cNoOfTicket;
	private Date dateCancel;
	private Tour tour;
	private BookTour bookTour;

	public CancelRegistration() {
	}

	public CancelRegistration(String cName, String cSex, String cEmail, String cPhone, String cAddress,
			int cNoOfTicket, Date dateCancel) {
		this.cName = cName;
		this.cSex = cSex;
		this.cEmail = cEmail;
		this.cPhone = cPhone;
		this.cAddress = cAddress;
		this.cNoOfTicket = cNoOfTicket;
		this.dateCancel = dateCancel;
	}

	public CancelRegistration(String cName, String cSex, String cEmail, String cPhone, String cAddress, int cNoOfTicket, Date dateCancel,
			Tour tour) {
		this.cName = cName;
		this.cSex = cSex;
		this.cEmail = cEmail;
		this.cPhone = cPhone;
		this.cAddress = cAddress;
		this.cNoOfTicket = cNoOfTicket;
		this.dateCancel = dateCancel;
		this.tour = tour;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "ID_CANCEL", nullable = false)
	public int getIdCancel() {
		return this.idCancel;
	}

	public void setIdCancel(int idCancel) {
		this.idCancel = idCancel;
	}

	// Create column customer name
	@Column(name = "C_NAME", nullable = false, length = 40)
	public String getcName() {
		return this.cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	// Create column customer sex
	@Column(name = "C_SEX", nullable = false)
	public String getcSex() {
		return this.cSex;
	}

	public void setcSex(String cSex) {
		this.cSex = cSex;
	}

	// Create column customer email
	@Column(name = "C_EMAIL", nullable = false, length = 50)
	public String getcEmail() {
		return this.cEmail;
	}

	public void setcEmail(String cEmail) {
		this.cEmail = cEmail;
	}

	// Create column customer phone
	@Column(name = "C_PHONE", nullable = false)
	public String getcPhone() {
		return this.cPhone;
	}

	public void setcPhone(String cPhone) {
		this.cPhone = cPhone;
	}

	// Create column customer address
	@Column(name = "C_ADDRESS", nullable = false, length = 100)
	public String getcAddress() {
		return this.cAddress;
	}

	public void setcAddress(String cAddress) {
		this.cAddress = cAddress;
	}

	// Create column Number of ticket
	@Column(name = "C_NOOFTICKET", nullable = false)
	public int getcNoOfTicket() {
		return this.cNoOfTicket;
	}

	public void setcNoOfTicket(int cNoOfTicket) {
		this.cNoOfTicket = cNoOfTicket;
	}

	// Create column Date book
	@Column(name = "DATE_CANCEL", nullable = false)
	@Temporal(TemporalType.DATE)
	public Date getDateCancel() {
		return this.dateCancel;
	}

	public void setDateCancel(LocalDate dateCancel) {
		this.dateCancel = Date.from(dateCancel.atStartOfDay(ZoneId.systemDefault()).toInstant());
	}

	// Join table TOUR by column ID_TOUR
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "ID_TOUR", nullable = true)
	public Tour getTour() {
		return tour;
	}

	public void setTour(Tour tour) {
		this.tour = tour;
	}

	// Join table BOOKTOUR by column ID_BT
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "ID_BT", nullable = true)
	public BookTour getBookTour() {
		return bookTour;
	}

	public void setBookTour(BookTour bookTour) {
		this.bookTour = bookTour;
	}

	@Override
	public int hashCode() {
		return idCancel;
	}

	@Override
	public String toString() {
		return this.getClass().getName() + "Id = " + idCancel;
	}

	@Override
	public boolean equals(Object cancelReg) {
		if (cancelReg == null || (cancelReg.getClass() != this.getClass())) {
			return false;
		} else {
			return this.idCancel == ((CancelRegistration) cancelReg).getIdCancel();
		}
	}
}
