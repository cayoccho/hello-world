package edu.ctu.thesis.travelsystem.service;

import java.util.List;
import java.util.Map;

import edu.ctu.thesis.travelsystem.model.BookTour;
import edu.ctu.thesis.travelsystem.model.RegistrationInfo;

public interface BookTourService {
	public void saveBookTour(BookTour bookTour, int idTour);
	
	public List<BookTour> listBookTour();
	
	public List<BookTour> registrationList(int idTour);
	
	public BookTour searchById(int idBT);
	
	public void editBookTour(BookTour bookTour);

	public void deleteBookTour(int idBT, int idTour);
	
	public BookTour searchByName(String cusName);
	
	public BookTour searchByEmail(String cusEmail);
	
	public BookTour searchByPhone(String cusPhone);
	
	public Integer getNumBookTour(int idTour);
	
	public List<BookTour> registrationListByValue(String value);
	
	public Integer getNumBTBySearch(String value);
	
	public Integer paginationX(Integer currentPage, Integer page);
	
	public Integer paginationY(Integer numOfPage, Integer currentPage, Integer page);
	
	public int getNoTicketBooked(int idTour);
	
	public int getNoTicketAvailability(int idTour);
	
	public Map getFields(int idTour);
	
	public void saveDesignForm(RegistrationInfo regInfo, int idTour);
}