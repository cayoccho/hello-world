package edu.ctu.thesis.travelsystem.service;

import java.util.List;

import edu.ctu.thesis.travelsystem.model.BookTour;
import edu.ctu.thesis.travelsystem.model.Relationship;

public interface RegInfoService {
	public List<BookTour> registrationList(int idTour);
	
	public void deleteBookTour(int idBT, int idTour);

	public List<BookTour> cancelList(int idTour);

	public List<BookTour> cancelListByValue(String value, int idTour);

	public void undoCancel(int idBT);
	
	public BookTour getFirstElement(int relationship);
	
	public void cancelAllBookTour(int idBT, int relationship);
	
	public List<Relationship> relationshipList();
	
	public void saveRelationship(Relationship relationship);
	
	public void deleteRelationship(int id);
	
	public void undoAllCancel(int idBT, int relationship);
	
	public void deleteAllBookTour(int idBT, int relationship);
}